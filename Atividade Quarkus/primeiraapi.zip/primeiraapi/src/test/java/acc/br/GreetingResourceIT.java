//package acc.br;
//
//import io.quarkus.test.junit.QuarkusIntegrationTest;
//
//@QuarkusIntegrationTest
//class GreetingResourceIT extends FrutasResourceTest {
//    // Execute the same tests but in packaged mode.
//}
