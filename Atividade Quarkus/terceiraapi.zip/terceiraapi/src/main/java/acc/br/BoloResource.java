package acc.br;

import java.util.List;

import acc.br.model.Bolo;
import acc.br.model.Product;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/bolos")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class BoloResource {

    @GET
    public List<Bolo> getAllBolos() {
        return Bolo.listAll();
    }

    @GET
    @Path("/{id}")
    public Bolo getBoloById(@PathParam("id") Long id) {
        return Bolo.findById(id);
    }

    @POST
    @Transactional
    public Response createBolo(Bolo bolo) {
    	bolo.persist();
        return Response.status(Response.Status.CREATED).entity(bolo).build();
    }

    @PUT
    @Path("/{id}")
    @Transactional
    public Response updateBolo(@PathParam("id") Long id, Product bolo) {
    	Bolo existingBolo = Product.findById(id);
        if (existingBolo == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        existingBolo.name = bolo.name;
        existingBolo.price = bolo.price;
        return Response.ok(existingBolo).build();
    }

    @DELETE
    @Path("/{id}")
    @Transactional
    public Response deleteBolo(@PathParam("id") Long id) {
    	Bolo bolo = Bolo.findById(id);
        if (bolo == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        bolo.delete();
        return Response.noContent().build();
    }
}

