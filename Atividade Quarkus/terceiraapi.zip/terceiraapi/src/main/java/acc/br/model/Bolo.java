package acc.br.model;
import io.quarkus.hibernate.orm.panache.PanacheEntity;
import jakarta.persistence.Entity;

@Entity
public class Bolo extends PanacheEntity {
    
    public String name;
    public double price;

    // Default constructor
    public Bolo() {}

    // Constructor with parameters
    public Bolo(String name, double price) {
        this.name = name;
        this.price = price;
    }
}
