package com.accenture.pessoa.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.pessoa.entity.Pessoa;
import com.accenture.pessoa.service.PessoaService;

@RestController
public class PessoaController {
    @Autowired
    private PessoaService pessoaService;

    @GetMapping("/pessoa")
    public List<Pessoa> getAll() {
        return pessoaService.getAllPessoas();
    }

    @GetMapping("/pessoa/{id}")
    public ResponseEntity<Pessoa> getById(@PathVariable(value = "id") long id) {
        return pessoaService.getPessoaById(id);
    }

    @PostMapping("/pessoa")
    public Pessoa create(@Valid @RequestBody Pessoa pessoa) {
        return pessoaService.createPessoa(pessoa);
    }

    @PutMapping("/pessoa/{id}")
    public ResponseEntity<Pessoa> update(@PathVariable(value = "id") long id, @Valid @RequestBody Pessoa newPessoa) {
        return pessoaService.updatePessoa(id, newPessoa);
    }

    @DeleteMapping("/pessoa/{id}")
    public ResponseEntity<Object> delete(@PathVariable(value = "id") long id) {
        return pessoaService.deletePessoa(id);
    }
}
