insert into Contato (id, nome, email) values (1, 'William Douglas', 'williamdouglas@gmail.com');
insert into Contato (id, nome, email) values (2, 'Al Ries', 'alries@hotmail.com');
insert into Contato (id, nome, email) values (3, 'Mortimer J. Adler', 'mortimeradler@gmail.com');
insert into Contato (id, nome, email) values (4, 'Christian Barbosa', 'christianbarbosa@gmail.com');
