package acc.br.contatos.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import acc.br.contatos.model.Contato;
import acc.br.contatos.repository.Contatos;

@Service
public class ContatosService {

	@Autowired
	private Contatos contatos;
	
	public List<Contato> findAll() {
		return contatos.findAll();
	}
}