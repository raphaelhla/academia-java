package acc.br.contatos_students;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContatosStudentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContatosStudentsApplication.class, args);
	}

}
