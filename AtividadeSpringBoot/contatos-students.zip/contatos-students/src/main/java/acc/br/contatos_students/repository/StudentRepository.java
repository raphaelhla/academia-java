package acc.br.contatos_students.repository;

import org.springframework.data.repository.CrudRepository;

import acc.br.contatos_students.model.Student;

public interface StudentRepository extends CrudRepository<Student, Integer>
{
}
