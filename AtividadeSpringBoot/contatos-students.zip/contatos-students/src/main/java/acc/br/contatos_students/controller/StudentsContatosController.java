package acc.br.contatos_students.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import acc.br.contatos_students.model.Contato;
import acc.br.contatos_students.model.Student;
import acc.br.contatos_students.service.ContatoService;
import acc.br.contatos_students.service.StudentService;

@Controller
@RequestMapping("/students-contatos")
public class StudentsContatosController {

	@Autowired
	StudentService studentService;
	
	@Autowired
	ContatoService contatoService;
	
	@GetMapping()
	public ModelAndView listarTodos() {
		List<Student> listaStudents = studentService.getAllStudent();
		List<Contato> listaContatos = contatoService.findAll();
		
		ModelAndView modelAndView = new ModelAndView("students-contatos");		
		modelAndView.addObject("students", listaStudents);
		modelAndView.addObject("contatos", listaContatos);
		
		return modelAndView;
	}
}
