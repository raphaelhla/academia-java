package acc.br.contatos_students.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import acc.br.contatos_students.model.Contato;

public interface ContatoRepository extends JpaRepository<Contato, Long> {

}
