package acc.br.contatos_students.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import acc.br.contatos_students.model.Contato;
import acc.br.contatos_students.repository.ContatoRepository;

@Service
public class ContatoService {

	@Autowired
	private ContatoRepository contatoRepository;
	
	public List<Contato> findAll() {
		return contatoRepository.findAll();
	}
}
