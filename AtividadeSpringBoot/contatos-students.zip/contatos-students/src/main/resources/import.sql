insert into Contato (id, nome, email) values (1, 'William Douglas', 'williamdouglas@gmail.com');
insert into Contato (id, nome, email) values (2, 'Al Ries', 'alries@hotmail.com');
insert into Contato (id, nome, email) values (3, 'Mortimer J. Adler', 'mortimeradler@gmail.com');
insert into Contato (id, nome, email) values (4, 'Christian Barbosa', 'christianbarbosa@gmail.com');

insert into Student (id, name, age, email) values (1, 'Raphael Agra', 24, 'raphael@gmail.com');
insert into Student (id, name, age, email) values (2, 'Ze Mane', 30, 'mane@gmail.com');
insert into Student (id, name, age, email) values (3, 'Biu Lopes', 35, 'biu@gmail.com');
insert into Student (id, name, age, email) values (4, 'Irineu Silva', 40, 'irineu@gmail.com');