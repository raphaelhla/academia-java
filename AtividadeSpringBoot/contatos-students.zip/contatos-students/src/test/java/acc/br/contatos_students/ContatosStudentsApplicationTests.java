package acc.br.contatos_students;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContatosStudentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
